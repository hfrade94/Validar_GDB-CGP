from qgis.PyQt.QtWidgets import QDialog, QVBoxLayout, QLabel, QPushButton, QScrollArea, QWidget
from qgis.PyQt.QtGui import QIcon  # Importe QIcon para carregar o ícone
import os  # Importe o módulo os para manipular caminhos de arquivo

class PopupDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Validar cadastro técnico - CAGEPA')
        
        # Define a largura fixa da janela para 200 pixels
        self.setFixedWidth(400)
        
        # Define o caminho para o ícone PNG
        icon_path = os.path.join(os.path.dirname(__file__), "icon_cagepa.png")  # Caminho relativo ao arquivo do plugin

        # Verifica se o arquivo de ícone existe
        if os.path.exists(icon_path):
            # Define o ícone da janela do popup
            self.setWindowIcon(QIcon(icon_path))
        else:
            print(f"Ícone não encontrado: {icon_path}")  # Mensagem de depuração

        # Cria um widget principal para o layout
        self.main_widget = QWidget()
        self.main_layout = QVBoxLayout(self.main_widget)

        # Cria um QLabel para exibir a mensagem
        self.label = QLabel(self.main_widget)
        self.label.setWordWrap(True)  # Permite que o texto quebre em várias linhas
        self.main_layout.addWidget(self.label)

        # Cria um QScrollArea para adicionar a barra de rolagem
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)  # Permite que o widget interno se ajuste ao tamanho
        self.scroll_area.setWidget(self.main_widget)

        # Cria o botão "OK"
        self.ok_button = QPushButton('OK', self)
        self.ok_button.clicked.connect(self.accept)

        # Define o layout do diálogo
        self.layout = QVBoxLayout(self)
        self.layout.addWidget(self.scroll_area)  # Adiciona o QScrollArea ao layout
        self.layout.addWidget(self.ok_button)  # Adiciona o botão "OK" ao layout

    def set_message(self, message):
        """Define a mensagem a ser exibida no popup."""
        self.label.setText(message)