# camadas_para_verificar.py

check_groups = {
    'REDE ÁGUA': [
        {
            'layer': "Bomba",
            'fields': [
                "datainstalacao",
                "tipobomba"
            ]
        },
        {
            'layer': "Booster",
            'fields': [
                "datainstalacao"
            ]
        },
        {
            'layer': "Conexao",
            'fields': [
                "datainstalacao",
                "tipoconexao"
            ]         
        },
        {
            'layer': "Emenda",
            'fields': [
                "datainstalacao",
                "tipoemenda"
            ]         
        },
        {
            'layer': "EstruturaRede",
            'fields': [
                "datainstalacao",
                "tipoestrutura"
            ]         
        },
        {
            'layer': "Reservatorio",
            'fields': [
                "datainstalacao",
                "capacidade"
            ]         
        },
        {
            'layer': "RamalLigacao",
            'fields': [
                "datainstalacao",
                "material",
                "diametro"
            ]         
        },
        {
            'layer': "RedeAgua",
            'fields': [
                "datainstalacao",
                "tipouso",
                "material",
                "diametro",
                "extensaoreal",
                "profundidade",
                "localizacaorede",
                "tipopavimento"
            ]         
        },
        {
            'layer': "ValvulaSistema",
            'fields': [
                "datainstalacao",
                "tipovalvula"
            ]         
        }
    ],
    'REDE ESGOTO': [
        {
            'layer': "EstruturaRede",
            'fields': [
                "datainstalacao",
                "tipoestrutura"
            ]
        },
        {
            'layer': "PocoVisita",
            'fields': [
                "datainstalacao",
                "tipopoco",
                "cotanivel",
                "cotafundo",
                "profundidadeinterior",
                "tipopavimento"
            ]
        },
        {
            'layer': "RamalLigacao",
            'fields': [
                "datainstalacao",
                "material",
                "diametro"
            ]         
        },
        {
            'layer': "RedeEsgoto",
            'fields': [
                "datainstalacao",
                "tiporedeesgoto",
                "material",
                "diametro",
                "extensaoreal",
                "localizacaorede",
                "tipopavimento"
            ]         
        }
    ]
}
